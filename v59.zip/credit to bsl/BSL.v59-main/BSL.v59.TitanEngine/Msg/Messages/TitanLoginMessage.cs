namespace BSL.v59.TitanEngine.Msg.Messages;

public abstract class TitanLoginMessage
{
    public static int GetMessageType()
    {
        return 10101;
    }
}