namespace BSL.v59.TitanEngine.Msg.Messages;

public abstract class TitanLoginFailedMessage
{
    public static int GetMessageType()
    {
        return 20103;
    }
}