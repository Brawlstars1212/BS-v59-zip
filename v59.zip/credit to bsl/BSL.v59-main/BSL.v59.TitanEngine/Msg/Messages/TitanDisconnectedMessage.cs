namespace BSL.v59.TitanEngine.Msg.Messages;

public abstract class TitanDisconnectedMessage
{
    public static int GetMessageType()
    {
        return 25892;
    }
}