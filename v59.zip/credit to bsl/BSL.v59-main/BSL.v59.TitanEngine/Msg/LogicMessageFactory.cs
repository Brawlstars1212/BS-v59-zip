﻿namespace BSL.v59.TitanEngine.Msg;

public abstract class LogicMessageFactory
{
    public abstract void Destruct();
}